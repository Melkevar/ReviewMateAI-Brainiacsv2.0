import express from 'express';
import multer from 'multer';
import { v4 as uuidv4 } from 'uuid';
import { contracts } from '../models/contracts.js';
import { analysisResults } from '../models/analysisResults.js';

const router = express.Router();
const upload = multer({ dest: 'uploads/' });

/**
 * @swagger
 * tags:
 *   name: Contracts
 *   description: Contract management and review
 */

/**
 * @swagger
 * /api/contracts/upload:
 *   post:
 *     summary: Upload a contract file for AI review
 *     tags: [Contracts]
 *     requestBody:
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             properties:
 *               file:
 *                 type: string
 *                 format: binary
 *     responses:
 *       201:
 *         description: Contract uploaded successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                 contractId:
 *                   type: string
 *       400:
 *         description: No file uploaded or invalid format
 */
router.post('/upload', upload.single('file'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: "No file uploaded" });
  }

  const allowed = ['.pdf', '.docx', '.doc'];
  const original = req.file.originalname.toLowerCase();
  const ext = original.substring(original.lastIndexOf('.'));
  if (!allowed.includes(ext)) {
    return res.status(400).json({ error: "Invalid file format. Allowed: PDF, DOCX, DOC" });
  }

  const newContract = {
    contractId: uuidv4(),
    userId: "u1", // placeholder - in real app derive from auth token
    fileName: req.file.originalname,
    filePath: req.file.path,
    uploadedAt: new Date().toISOString(),
    status: "Pending"
  };

  contracts.push(newContract);

  // Create a dummy analysis result for demonstration
  analysisResults.push({
    contractId: newContract.contractId,
    riskScore: 42,
    issues: [
      {
        clause: "Termination",
        riskLevel: "Medium",
        description: "Unclear notice period",
        recommendation: "Specify notice period of at least 30 days."
      }
    ]
  });

  res.status(201).json({ message: "Contract uploaded successfully", contractId: newContract.contractId });
});

/**
 * @swagger
 * /api/contracts:
 *   get:
 *     summary: Retrieve all uploaded contracts for the logged-in user
 *     tags: [Contracts]
 *     parameters:
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *         description: Page number (starts at 1)
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *         description: Number of results per page
 *     responses:
 *       200:
 *         description: List of contracts
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 data:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       contractId:
 *                         type: string
 *                       fileName:
 *                         type: string
 *                       uploadDate:
 *                         type: string
 *                 page:
 *                   type: integer
 *                 limit:
 *                   type: integer
 *                 total:
 *                   type: integer
 */
router.get('/', (req, res) => {
  const page = parseInt(req.query.page || '1');
  const limit = parseInt(req.query.limit || '10');
  const start = (page - 1) * limit;
  const end = start + limit;

  const items = contracts.map(c => ({
    contractId: c.contractId,
    fileName: c.fileName,
    uploadDate: c.uploadedAt.split('T')[0]
  }));

  res.json({
    data: items.slice(start, end),
    page,
    limit,
    total: items.length
  });
});

/**
 * @swagger
 * /api/contracts/{id}/review:
 *   get:
 *     summary: Get AI review results for a specific contract
 *     tags: [Contracts]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Contract ID
 *     responses:
 *       200:
 *         description: Analysis result
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *       404:
 *         description: No review found
 */
router.get('/:id/review', (req, res) => {
  const { id } = req.params;
  const result = analysisResults.find(r => r.contractId === id);

  if (!result) {
    return res.status(404).json({ error: "No review found" });
  }

  res.json(result);
});

/**
 * @swagger
 * /api/contracts/{id}:
 *   delete:
 *     summary: Delete a contract by ID
 *     tags: [Contracts]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Contract ID
 *     responses:
 *       200:
 *         description: Deleted successfully
 *       404:
 *         description: Contract not found
 */
router.delete('/:id', (req, res) => {
  const { id } = req.params;
  const index = contracts.findIndex(c => c.contractId === id);

  if (index === -1) {
    return res.status(404).json({ error: "Contract not found" });
  }

  contracts.splice(index, 1);

  // Remove any analysis results too
  const aiIndex = analysisResults.findIndex(r => r.contractId === id);
  if (aiIndex !== -1) analysisResults.splice(aiIndex, 1);

  res.json({ message: "Contract deleted successfully" });
});

export default router;
