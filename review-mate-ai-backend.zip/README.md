# Review Mate AI - Backend (Assignment 4)

## How to run (GitHub Codespaces / Termux / Local)

1. Open terminal in the `backend` folder:
   ```bash
   cd backend
   npm install
   npm start
   ```
2. Server will start on port 3000 (or $PORT if set).
3. Open Swagger UI: `http://localhost:3000/api-docs`

## Notes
- This project uses in-memory arrays (no persistent DB).
- Auth returns a fake JWT token for demo purposes.
- Uploaded files are stored in `uploads/` (created by multer).
