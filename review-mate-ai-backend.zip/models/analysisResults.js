export const analysisResults = [];
